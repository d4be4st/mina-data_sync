--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP INDEX public.idx_63692_index_users_on_reset_password_token;
DROP INDEX public.idx_63692_index_users_on_email;
DROP INDEX public.idx_63683_record_translations_index;
DROP INDEX public.idx_63652_index_transactions_on_client_id;
DROP INDEX public.idx_63652_index_transactions_on_charter_company_id;
DROP INDEX public.idx_63652_index_transactions_on_base_out_id;
DROP INDEX public.idx_63652_index_transactions_on_base_in_id;
DROP INDEX public.idx_63652_index_transactions_on_agent_id;
DROP INDEX public.idx_63632_index_ship_models_on_ship_manufacturer_id;
DROP INDEX public.idx_63611_index_ships_on_ship_model_id;
DROP INDEX public.idx_63611_index_ships_on_base_port_id;
DROP INDEX public.idx_63605_index_season_ships_on_ship_id;
DROP INDEX public.idx_63605_index_season_ships_on_season_id;
DROP INDEX public.idx_63588_unique_schema_migrations;
DROP INDEX public.idx_63585_index_sailings_transactions_on_transaction_id;
DROP INDEX public.idx_63585_index_sailings_transactions_on_sailing_id;
DROP INDEX public.idx_63571_index_regions_on_ancestry;
DROP INDEX public.idx_63565_index_price_per_weeks_on_season_ship_id;
DROP INDEX public.idx_63538_index_images_on_item_id_and_item_type;
DROP INDEX public.idx_63532_index_fees_on_charter_company_id;
DROP INDEX public.idx_63494_index_equipment_ships_on_ship_id_and_equipment_id;
DROP INDEX public.idx_63494_index_equipment_ships_on_equipment_id_and_ship_id;
DROP INDEX public.idx_63454_index_charter_company_base_port_infos_on_charter_comp;
DROP INDEX public.idx_63454_index_charter_company_base_port_infos_on_base_port_id;
ALTER TABLE ONLY public.users DROP CONSTRAINT idx_63692_primary;
ALTER TABLE ONLY public.translations DROP CONSTRAINT idx_63683_primary;
ALTER TABLE ONLY public.transit_log_templates DROP CONSTRAINT idx_63674_primary;
ALTER TABLE ONLY public.transit_log_items DROP CONSTRAINT idx_63662_primary;
ALTER TABLE ONLY public.transactions DROP CONSTRAINT idx_63652_primary;
ALTER TABLE ONLY public.to_do_items DROP CONSTRAINT idx_63641_primary;
ALTER TABLE ONLY public.ship_models DROP CONSTRAINT idx_63632_primary;
ALTER TABLE ONLY public.ship_manufacturers DROP CONSTRAINT idx_63623_primary;
ALTER TABLE ONLY public.ships DROP CONSTRAINT idx_63611_primary;
ALTER TABLE ONLY public.season_ships DROP CONSTRAINT idx_63605_primary;
ALTER TABLE ONLY public.seasons DROP CONSTRAINT idx_63596_primary;
ALTER TABLE ONLY public.sailings DROP CONSTRAINT idx_63580_primary;
ALTER TABLE ONLY public.regions DROP CONSTRAINT idx_63571_primary;
ALTER TABLE ONLY public.price_per_weeks DROP CONSTRAINT idx_63565_primary;
ALTER TABLE ONLY public.price_lists DROP CONSTRAINT idx_63553_primary;
ALTER TABLE ONLY public.periods DROP CONSTRAINT idx_63547_primary;
ALTER TABLE ONLY public.images DROP CONSTRAINT idx_63538_primary;
ALTER TABLE ONLY public.fees DROP CONSTRAINT idx_63532_primary;
ALTER TABLE ONLY public.extra_templates DROP CONSTRAINT idx_63520_primary;
ALTER TABLE ONLY public.extra_items DROP CONSTRAINT idx_63508_primary;
ALTER TABLE ONLY public.expenses DROP CONSTRAINT idx_63499_primary;
ALTER TABLE ONLY public.equipment DROP CONSTRAINT idx_63487_primary;
ALTER TABLE ONLY public.deposit_items DROP CONSTRAINT idx_63475_primary;
ALTER TABLE ONLY public.charter_packs DROP CONSTRAINT idx_63463_primary;
ALTER TABLE ONLY public.charter_company_base_port_infos DROP CONSTRAINT idx_63454_primary;
ALTER TABLE ONLY public.charter_companies DROP CONSTRAINT idx_63445_primary;
ALTER TABLE ONLY public.catalogues DROP CONSTRAINT idx_63436_primary;
ALTER TABLE ONLY public.base_port_managers DROP CONSTRAINT idx_63427_primary;
ALTER TABLE ONLY public.base_ports DROP CONSTRAINT idx_63415_primary;
ALTER TABLE ONLY public.attachments DROP CONSTRAINT idx_63406_primary;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.translations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.transit_log_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.transit_log_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.transactions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.to_do_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ships ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ship_models ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ship_manufacturers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.seasons ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.season_ships ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sailings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.regions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.price_per_weeks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.price_lists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.periods ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.fees ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.extra_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.extra_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.expenses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.equipment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.deposit_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.charter_packs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.charter_company_base_port_infos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.charter_companies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.catalogues ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.base_ports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.base_port_managers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.attachments ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.translations_id_seq;
DROP TABLE public.translations;
DROP SEQUENCE public.transit_log_templates_id_seq;
DROP TABLE public.transit_log_templates;
DROP TABLE public.transit_log_items_templates;
DROP SEQUENCE public.transit_log_items_id_seq;
DROP TABLE public.transit_log_items;
DROP SEQUENCE public.transactions_id_seq;
DROP TABLE public.transactions;
DROP SEQUENCE public.to_do_items_id_seq;
DROP TABLE public.to_do_items;
DROP TABLE public.ships_transit_log_templates;
DROP SEQUENCE public.ships_id_seq;
DROP TABLE public.ships;
DROP SEQUENCE public.ship_models_id_seq;
DROP TABLE public.ship_models;
DROP SEQUENCE public.ship_manufacturers_id_seq;
DROP TABLE public.ship_manufacturers;
DROP SEQUENCE public.seasons_id_seq;
DROP TABLE public.seasons;
DROP SEQUENCE public.season_ships_id_seq;
DROP TABLE public.season_ships;
DROP TABLE public.schema_migrations;
DROP TABLE public.sailings_transactions;
DROP SEQUENCE public.sailings_id_seq;
DROP TABLE public.sailings;
DROP SEQUENCE public.regions_id_seq;
DROP TABLE public.regions;
DROP SEQUENCE public.price_per_weeks_id_seq;
DROP TABLE public.price_per_weeks;
DROP TABLE public.price_lists_ships;
DROP SEQUENCE public.price_lists_id_seq;
DROP TABLE public.price_lists;
DROP SEQUENCE public.periods_id_seq;
DROP TABLE public.periods;
DROP SEQUENCE public.images_id_seq;
DROP TABLE public.images;
DROP SEQUENCE public.fees_id_seq;
DROP TABLE public.fees;
DROP TABLE public.extra_templates_ships;
DROP SEQUENCE public.extra_templates_id_seq;
DROP TABLE public.extra_templates;
DROP TABLE public.extra_items_templates;
DROP SEQUENCE public.extra_items_id_seq;
DROP TABLE public.extra_items;
DROP SEQUENCE public.expenses_id_seq;
DROP TABLE public.expenses;
DROP TABLE public.equipment_ships;
DROP SEQUENCE public.equipment_id_seq;
DROP TABLE public.equipment;
DROP TABLE public.deposit_items_ships;
DROP SEQUENCE public.deposit_items_id_seq;
DROP TABLE public.deposit_items;
DROP TABLE public.charter_packs_ships;
DROP SEQUENCE public.charter_packs_id_seq;
DROP TABLE public.charter_packs;
DROP SEQUENCE public.charter_company_base_port_infos_id_seq;
DROP TABLE public.charter_company_base_port_infos;
DROP SEQUENCE public.charter_companies_id_seq;
DROP TABLE public.charter_companies;
DROP SEQUENCE public.catalogues_id_seq;
DROP TABLE public.catalogues;
DROP SEQUENCE public.base_ports_id_seq;
DROP TABLE public.base_ports_charter_companies;
DROP TABLE public.base_ports;
DROP SEQUENCE public.base_port_managers_id_seq;
DROP TABLE public.base_port_managers;
DROP SEQUENCE public.attachments_id_seq;
DROP TABLE public.attachments;
DROP EXTENSION pgcrypto;
DROP EXTENSION adminpack;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: attachments; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE attachments (
    id bigint NOT NULL,
    attached_to_id bigint,
    attached_to_type text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    file_file_name text,
    file_content_type text,
    file_file_size bigint,
    file_updated_at timestamp with time zone,
    category text
);


--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE attachments_id_seq OWNED BY attachments.id;


--
-- Name: base_port_managers; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE base_port_managers (
    id bigint NOT NULL,
    name text,
    contact text,
    charter_company_id bigint,
    base_port_id bigint
);


--
-- Name: base_port_managers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE base_port_managers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: base_port_managers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE base_port_managers_id_seq OWNED BY base_port_managers.id;


--
-- Name: base_ports; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE base_ports (
    id bigint NOT NULL,
    name text,
    address text,
    region_id bigint,
    contact text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    latitude double precision,
    longitude double precision,
    city text,
    description text
);


--
-- Name: base_ports_charter_companies; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE base_ports_charter_companies (
    charter_company_id bigint,
    base_port_id bigint
);


--
-- Name: base_ports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE base_ports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: base_ports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE base_ports_id_seq OWNED BY base_ports.id;


--
-- Name: catalogues; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE catalogues (
    id bigint NOT NULL,
    name text,
    charter_company_id bigint,
    year bigint,
    active boolean
);


--
-- Name: catalogues_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE catalogues_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: catalogues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE catalogues_id_seq OWNED BY catalogues.id;


--
-- Name: charter_companies; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE charter_companies (
    id bigint NOT NULL,
    code text,
    name text,
    fullname text,
    city text,
    address text,
    phone text,
    fax text,
    url text,
    email text,
    country_code text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    info text,
    general_charter_conditions text,
    payment_type_id bigint,
    billing_method_id bigint,
    account_number text,
    transit_log_payment_id bigint,
    account_for_billing text,
    check_in_time time without time zone,
    check_out_time time without time zone,
    check_in_day bigint,
    check_out_day bigint,
    payment_instructions text
);


--
-- Name: charter_companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE charter_companies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: charter_companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE charter_companies_id_seq OWNED BY charter_companies.id;


--
-- Name: charter_company_base_port_infos; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE charter_company_base_port_infos (
    id bigint NOT NULL,
    charter_company_id bigint,
    base_port_id bigint,
    city text,
    address text,
    country_code text,
    phone text,
    fax text,
    info text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: charter_company_base_port_infos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE charter_company_base_port_infos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: charter_company_base_port_infos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE charter_company_base_port_infos_id_seq OWNED BY charter_company_base_port_infos.id;


--
-- Name: charter_packs; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE charter_packs (
    id bigint NOT NULL,
    name text,
    description text,
    season_id bigint
);


--
-- Name: charter_packs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE charter_packs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: charter_packs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE charter_packs_id_seq OWNED BY charter_packs.id;


--
-- Name: charter_packs_ships; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE charter_packs_ships (
    charter_pack_id bigint,
    ship_id bigint
);


--
-- Name: deposit_items; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE deposit_items (
    id bigint NOT NULL,
    name text,
    price text,
    deposit_type_id bigint,
    charter_company_id bigint
);


--
-- Name: deposit_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE deposit_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deposit_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE deposit_items_id_seq OWNED BY deposit_items.id;


--
-- Name: deposit_items_ships; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE deposit_items_ships (
    deposit_item_id bigint,
    ship_id bigint
);


--
-- Name: equipment; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE equipment (
    id bigint NOT NULL,
    name text,
    equipment_type_id bigint,
    equipment_category_id bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    ship_type_id bigint,
    "position" bigint
);


--
-- Name: equipment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE equipment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: equipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE equipment_id_seq OWNED BY equipment.id;


--
-- Name: equipment_ships; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE equipment_ships (
    equipment_id bigint NOT NULL,
    ship_id bigint NOT NULL
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE expenses (
    id bigint NOT NULL,
    name text,
    description text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE expenses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE expenses_id_seq OWNED BY expenses.id;


--
-- Name: extra_items; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE extra_items (
    id bigint NOT NULL,
    name text,
    charter_company_id bigint
);


--
-- Name: extra_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE extra_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: extra_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE extra_items_id_seq OWNED BY extra_items.id;


--
-- Name: extra_items_templates; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE extra_items_templates (
    extra_item_id bigint,
    extra_template_id bigint
);


--
-- Name: extra_templates; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE extra_templates (
    id bigint NOT NULL,
    name text,
    charter_company_id bigint,
    price double precision
);


--
-- Name: extra_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE extra_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: extra_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE extra_templates_id_seq OWNED BY extra_templates.id;


--
-- Name: extra_templates_ships; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE extra_templates_ships (
    extra_template_id bigint,
    ship_id bigint
);


--
-- Name: fees; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE fees (
    id bigint NOT NULL,
    charter_company_id bigint,
    ship_type_id bigint,
    price double precision,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: fees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE fees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE fees_id_seq OWNED BY fees.id;


--
-- Name: images; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE images (
    id bigint NOT NULL,
    item_id bigint,
    item_type text,
    image_type_id bigint,
    image_file_name text,
    image_content_type text,
    image_file_size bigint,
    image_updated_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE images_id_seq OWNED BY images.id;


--
-- Name: periods; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE periods (
    id bigint NOT NULL,
    start_date date,
    end_date date,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    season_id bigint
);


--
-- Name: periods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE periods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE periods_id_seq OWNED BY periods.id;


--
-- Name: price_lists; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE price_lists (
    id bigint NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name text,
    season_id bigint
);


--
-- Name: price_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE price_lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: price_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE price_lists_id_seq OWNED BY price_lists.id;


--
-- Name: price_lists_ships; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE price_lists_ships (
    price_list_id bigint,
    ship_id bigint
);


--
-- Name: price_per_weeks; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE price_per_weeks (
    id bigint NOT NULL,
    season_ship_id bigint,
    price double precision,
    start date,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: price_per_weeks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE price_per_weeks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: price_per_weeks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE price_per_weeks_id_seq OWNED BY price_per_weeks.id;


--
-- Name: regions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE regions (
    id bigint NOT NULL,
    name text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent_id bigint,
    latitude double precision,
    longitude double precision,
    season_id bigint,
    ancestry text,
    description text
);


--
-- Name: regions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE regions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE regions_id_seq OWNED BY regions.id;


--
-- Name: sailings; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE sailings (
    id bigint NOT NULL,
    season_ship_id bigint,
    start_date date,
    price double precision,
    price_changed boolean DEFAULT false
);


--
-- Name: sailings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE sailings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sailings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE sailings_id_seq OWNED BY sailings.id;


--
-- Name: sailings_transactions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE sailings_transactions (
    transaction_id bigint,
    sailing_id bigint
);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE schema_migrations (
    version text NOT NULL
);


--
-- Name: season_ships; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE season_ships (
    id bigint NOT NULL,
    ship_id bigint,
    season_id bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    price double precision
);


--
-- Name: season_ships_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE season_ships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: season_ships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE season_ships_id_seq OWNED BY season_ships.id;


--
-- Name: seasons; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE seasons (
    id bigint NOT NULL,
    name text,
    catalogue_id bigint,
    price double precision
);


--
-- Name: seasons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE seasons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: seasons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE seasons_id_seq OWNED BY seasons.id;


--
-- Name: ship_manufacturers; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE ship_manufacturers (
    id bigint NOT NULL,
    name text,
    country_code text,
    url text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: ship_manufacturers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE ship_manufacturers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ship_manufacturers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE ship_manufacturers_id_seq OWNED BY ship_manufacturers.id;


--
-- Name: ship_models; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE ship_models (
    id bigint NOT NULL,
    name text,
    ship_manufacturer_id bigint,
    ship_type_id bigint,
    hull_type_id bigint,
    fuel_type_id bigint,
    length double precision,
    beam double precision,
    draught double precision,
    fuel_capacity double precision,
    water_capacity double precision,
    no_of_engines bigint,
    engine_power double precision,
    engine_name text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    variant text
);


--
-- Name: ship_models_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE ship_models_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ship_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE ship_models_id_seq OWNED BY ship_models.id;


--
-- Name: ships; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE ships (
    id bigint NOT NULL,
    name text,
    charter_company_id bigint,
    ship_model_id bigint,
    base_port_id bigint,
    year_of_manufacture bigint,
    no_of_engines bigint,
    engine_name text,
    engine_power double precision,
    fuel_type_id bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    description text,
    length double precision,
    beam double precision,
    draught double precision,
    fuel_capacity double precision,
    water_capacity double precision,
    max_no_of_people bigint,
    no_of_berths text,
    no_of_crew_cabins bigint,
    no_of_heads bigint,
    variant text,
    no_of_bunk_cabins bigint,
    no_of_double_cabins bigint,
    no_of_skipper_cabins bigint,
    hull_type_id bigint,
    ship_type_id bigint,
    no_of_single_cabins bigint,
    no_of_triple_cabins bigint,
    charter_type_id bigint
);


--
-- Name: ships_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE ships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE ships_id_seq OWNED BY ships.id;


--
-- Name: ships_transit_log_templates; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE ships_transit_log_templates (
    ship_id bigint,
    transit_log_template_id bigint
);


--
-- Name: to_do_items; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE to_do_items (
    id bigint NOT NULL,
    "position" bigint DEFAULT 0::bigint,
    text text,
    status boolean DEFAULT false,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    assignee_id bigint,
    assignee_type text,
    user_id bigint,
    due_date date
);


--
-- Name: to_do_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE to_do_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: to_do_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE to_do_items_id_seq OWNED BY to_do_items.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE transactions (
    id bigint NOT NULL,
    transaction_status_id bigint,
    check_in date,
    check_out date,
    base_in_id bigint,
    base_out_id bigint,
    charter_company_id bigint,
    client_id bigint,
    price text,
    payment_type_id bigint,
    agency_agreement text,
    agent_id bigint,
    creation_date date,
    option_date date,
    expiry_date date,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    notes text,
    payment_status double precision DEFAULT 0::double precision,
    reservation_date date,
    bank_info text,
    bank_remark text
);


--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE transactions_id_seq OWNED BY transactions.id;


--
-- Name: transit_log_items; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE transit_log_items (
    id bigint NOT NULL,
    name text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: transit_log_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE transit_log_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transit_log_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE transit_log_items_id_seq OWNED BY transit_log_items.id;


--
-- Name: transit_log_items_templates; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE transit_log_items_templates (
    transit_log_item_id bigint,
    transit_log_template_id bigint
);


--
-- Name: transit_log_templates; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE transit_log_templates (
    id bigint NOT NULL,
    name text,
    price double precision,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    charter_company_id bigint
);


--
-- Name: transit_log_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE transit_log_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transit_log_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE transit_log_templates_id_seq OWNED BY transit_log_templates.id;


--
-- Name: translations; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE translations (
    id bigint NOT NULL,
    translatable_id bigint,
    translatable_type text,
    translatable_field text,
    locale text,
    content text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: translations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE translations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: translations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE translations_id_seq OWNED BY translations.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users (
    id bigint NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    encrypted_password text DEFAULT ''::text NOT NULL,
    reset_password_token text,
    reset_password_sent_at timestamp with time zone,
    remember_created_at timestamp with time zone,
    sign_in_count bigint DEFAULT 0::bigint NOT NULL,
    current_sign_in_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    current_sign_in_ip text,
    last_sign_in_ip text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    role_id bigint
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY attachments ALTER COLUMN id SET DEFAULT nextval('attachments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY base_port_managers ALTER COLUMN id SET DEFAULT nextval('base_port_managers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY base_ports ALTER COLUMN id SET DEFAULT nextval('base_ports_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY catalogues ALTER COLUMN id SET DEFAULT nextval('catalogues_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY charter_companies ALTER COLUMN id SET DEFAULT nextval('charter_companies_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY charter_company_base_port_infos ALTER COLUMN id SET DEFAULT nextval('charter_company_base_port_infos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY charter_packs ALTER COLUMN id SET DEFAULT nextval('charter_packs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY deposit_items ALTER COLUMN id SET DEFAULT nextval('deposit_items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY equipment ALTER COLUMN id SET DEFAULT nextval('equipment_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY expenses ALTER COLUMN id SET DEFAULT nextval('expenses_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY extra_items ALTER COLUMN id SET DEFAULT nextval('extra_items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY extra_templates ALTER COLUMN id SET DEFAULT nextval('extra_templates_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY fees ALTER COLUMN id SET DEFAULT nextval('fees_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY images ALTER COLUMN id SET DEFAULT nextval('images_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY periods ALTER COLUMN id SET DEFAULT nextval('periods_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY price_lists ALTER COLUMN id SET DEFAULT nextval('price_lists_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY price_per_weeks ALTER COLUMN id SET DEFAULT nextval('price_per_weeks_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY regions ALTER COLUMN id SET DEFAULT nextval('regions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY sailings ALTER COLUMN id SET DEFAULT nextval('sailings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY season_ships ALTER COLUMN id SET DEFAULT nextval('season_ships_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY seasons ALTER COLUMN id SET DEFAULT nextval('seasons_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY ship_manufacturers ALTER COLUMN id SET DEFAULT nextval('ship_manufacturers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY ship_models ALTER COLUMN id SET DEFAULT nextval('ship_models_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY ships ALTER COLUMN id SET DEFAULT nextval('ships_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY to_do_items ALTER COLUMN id SET DEFAULT nextval('to_do_items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY transactions ALTER COLUMN id SET DEFAULT nextval('transactions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY transit_log_items ALTER COLUMN id SET DEFAULT nextval('transit_log_items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY transit_log_templates ALTER COLUMN id SET DEFAULT nextval('transit_log_templates_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY translations ALTER COLUMN id SET DEFAULT nextval('translations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY attachments (id, attached_to_id, attached_to_type, created_at, updated_at, file_file_name, file_content_type, file_file_size, file_updated_at, category) FROM stdin;
\.
COPY attachments (id, attached_to_id, attached_to_type, created_at, updated_at, file_file_name, file_content_type, file_file_size, file_updated_at, category) FROM '$$PATH$$/2601.dat';

--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('attachments_id_seq', 1, true);


--
-- Data for Name: base_port_managers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY base_port_managers (id, name, contact, charter_company_id, base_port_id) FROM stdin;
\.
COPY base_port_managers (id, name, contact, charter_company_id, base_port_id) FROM '$$PATH$$/2606.dat';

--
-- Name: base_port_managers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('base_port_managers_id_seq', 1, true);


--
-- Data for Name: base_ports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY base_ports (id, name, address, region_id, contact, created_at, updated_at, latitude, longitude, city, description) FROM stdin;
\.
COPY base_ports (id, name, address, region_id, contact, created_at, updated_at, latitude, longitude, city, description) FROM '$$PATH$$/2603.dat';

--
-- Data for Name: base_ports_charter_companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY base_ports_charter_companies (charter_company_id, base_port_id) FROM stdin;
\.
COPY base_ports_charter_companies (charter_company_id, base_port_id) FROM '$$PATH$$/2604.dat';

--
-- Name: base_ports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('base_ports_id_seq', 108, true);


--
-- Data for Name: catalogues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY catalogues (id, name, charter_company_id, year, active) FROM stdin;
\.
COPY catalogues (id, name, charter_company_id, year, active) FROM '$$PATH$$/2608.dat';

--
-- Name: catalogues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('catalogues_id_seq', 5, true);


--
-- Data for Name: charter_companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY charter_companies (id, code, name, fullname, city, address, phone, fax, url, email, country_code, created_at, updated_at, info, general_charter_conditions, payment_type_id, billing_method_id, account_number, transit_log_payment_id, account_for_billing, check_in_time, check_out_time, check_in_day, check_out_day, payment_instructions) FROM stdin;
\.
COPY charter_companies (id, code, name, fullname, city, address, phone, fax, url, email, country_code, created_at, updated_at, info, general_charter_conditions, payment_type_id, billing_method_id, account_number, transit_log_payment_id, account_for_billing, check_in_time, check_out_time, check_in_day, check_out_day, payment_instructions) FROM '$$PATH$$/2610.dat';

--
-- Name: charter_companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('charter_companies_id_seq', 10318, true);


--
-- Data for Name: charter_company_base_port_infos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY charter_company_base_port_infos (id, charter_company_id, base_port_id, city, address, country_code, phone, fax, info, created_at, updated_at) FROM stdin;
\.
COPY charter_company_base_port_infos (id, charter_company_id, base_port_id, city, address, country_code, phone, fax, info, created_at, updated_at) FROM '$$PATH$$/2612.dat';

--
-- Name: charter_company_base_port_infos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('charter_company_base_port_infos_id_seq', 3, true);


--
-- Data for Name: charter_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY charter_packs (id, name, description, season_id) FROM stdin;
\.
COPY charter_packs (id, name, description, season_id) FROM '$$PATH$$/2614.dat';

--
-- Name: charter_packs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('charter_packs_id_seq', 1, true);


--
-- Data for Name: charter_packs_ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY charter_packs_ships (charter_pack_id, ship_id) FROM stdin;
\.
COPY charter_packs_ships (charter_pack_id, ship_id) FROM '$$PATH$$/2615.dat';

--
-- Data for Name: deposit_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY deposit_items (id, name, price, deposit_type_id, charter_company_id) FROM stdin;
\.
COPY deposit_items (id, name, price, deposit_type_id, charter_company_id) FROM '$$PATH$$/2617.dat';

--
-- Name: deposit_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('deposit_items_id_seq', 2, true);


--
-- Data for Name: deposit_items_ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY deposit_items_ships (deposit_item_id, ship_id) FROM stdin;
\.
COPY deposit_items_ships (deposit_item_id, ship_id) FROM '$$PATH$$/2618.dat';

--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY equipment (id, name, equipment_type_id, equipment_category_id, created_at, updated_at, ship_type_id, "position") FROM stdin;
\.
COPY equipment (id, name, equipment_type_id, equipment_category_id, created_at, updated_at, ship_type_id, "position") FROM '$$PATH$$/2620.dat';

--
-- Name: equipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('equipment_id_seq', 401, true);


--
-- Data for Name: equipment_ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY equipment_ships (equipment_id, ship_id) FROM stdin;
\.
COPY equipment_ships (equipment_id, ship_id) FROM '$$PATH$$/2621.dat';

--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY expenses (id, name, description, created_at, updated_at) FROM stdin;
\.
COPY expenses (id, name, description, created_at, updated_at) FROM '$$PATH$$/2623.dat';

--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('expenses_id_seq', 1, true);


--
-- Data for Name: extra_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY extra_items (id, name, charter_company_id) FROM stdin;
\.
COPY extra_items (id, name, charter_company_id) FROM '$$PATH$$/2625.dat';

--
-- Name: extra_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('extra_items_id_seq', 2, true);


--
-- Data for Name: extra_items_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY extra_items_templates (extra_item_id, extra_template_id) FROM stdin;
\.
COPY extra_items_templates (extra_item_id, extra_template_id) FROM '$$PATH$$/2626.dat';

--
-- Data for Name: extra_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY extra_templates (id, name, charter_company_id, price) FROM stdin;
\.
COPY extra_templates (id, name, charter_company_id, price) FROM '$$PATH$$/2628.dat';

--
-- Name: extra_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('extra_templates_id_seq', 2, true);


--
-- Data for Name: extra_templates_ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY extra_templates_ships (extra_template_id, ship_id) FROM stdin;
\.
COPY extra_templates_ships (extra_template_id, ship_id) FROM '$$PATH$$/2629.dat';

--
-- Data for Name: fees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY fees (id, charter_company_id, ship_type_id, price, created_at, updated_at) FROM stdin;
\.
COPY fees (id, charter_company_id, ship_type_id, price, created_at, updated_at) FROM '$$PATH$$/2631.dat';

--
-- Name: fees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('fees_id_seq', 12, true);


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY images (id, item_id, item_type, image_type_id, image_file_name, image_content_type, image_file_size, image_updated_at, created_at, updated_at) FROM stdin;
\.
COPY images (id, item_id, item_type, image_type_id, image_file_name, image_content_type, image_file_size, image_updated_at, created_at, updated_at) FROM '$$PATH$$/2633.dat';

--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('images_id_seq', 5, true);


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY periods (id, start_date, end_date, created_at, updated_at, season_id) FROM stdin;
\.
COPY periods (id, start_date, end_date, created_at, updated_at, season_id) FROM '$$PATH$$/2635.dat';

--
-- Name: periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('periods_id_seq', 16, true);


--
-- Data for Name: price_lists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY price_lists (id, created_at, updated_at, name, season_id) FROM stdin;
\.
COPY price_lists (id, created_at, updated_at, name, season_id) FROM '$$PATH$$/2637.dat';

--
-- Name: price_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('price_lists_id_seq', 2, true);


--
-- Data for Name: price_lists_ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY price_lists_ships (price_list_id, ship_id) FROM stdin;
\.
COPY price_lists_ships (price_list_id, ship_id) FROM '$$PATH$$/2638.dat';

--
-- Data for Name: price_per_weeks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY price_per_weeks (id, season_ship_id, price, start, created_at, updated_at) FROM stdin;
\.
COPY price_per_weeks (id, season_ship_id, price, start, created_at, updated_at) FROM '$$PATH$$/2640.dat';

--
-- Name: price_per_weeks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('price_per_weeks_id_seq', 1, true);


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY regions (id, name, created_at, updated_at, parent_id, latitude, longitude, season_id, ancestry, description) FROM stdin;
\.
COPY regions (id, name, created_at, updated_at, parent_id, latitude, longitude, season_id, ancestry, description) FROM '$$PATH$$/2642.dat';

--
-- Name: regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('regions_id_seq', 50687, true);


--
-- Data for Name: sailings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY sailings (id, season_ship_id, start_date, price, price_changed) FROM stdin;
\.
COPY sailings (id, season_ship_id, start_date, price, price_changed) FROM '$$PATH$$/2644.dat';

--
-- Name: sailings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('sailings_id_seq', 203, true);


--
-- Data for Name: sailings_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY sailings_transactions (transaction_id, sailing_id) FROM stdin;
\.
COPY sailings_transactions (transaction_id, sailing_id) FROM '$$PATH$$/2645.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY schema_migrations (version) FROM stdin;
\.
COPY schema_migrations (version) FROM '$$PATH$$/2646.dat';

--
-- Data for Name: season_ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY season_ships (id, ship_id, season_id, created_at, updated_at, price) FROM stdin;
\.
COPY season_ships (id, ship_id, season_id, created_at, updated_at, price) FROM '$$PATH$$/2650.dat';

--
-- Name: season_ships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('season_ships_id_seq', 46, true);


--
-- Data for Name: seasons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY seasons (id, name, catalogue_id, price) FROM stdin;
\.
COPY seasons (id, name, catalogue_id, price) FROM '$$PATH$$/2648.dat';

--
-- Name: seasons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seasons_id_seq', 9, true);


--
-- Data for Name: ship_manufacturers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ship_manufacturers (id, name, country_code, url, created_at, updated_at) FROM stdin;
\.
COPY ship_manufacturers (id, name, country_code, url, created_at, updated_at) FROM '$$PATH$$/2655.dat';

--
-- Name: ship_manufacturers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('ship_manufacturers_id_seq', 10321, true);


--
-- Data for Name: ship_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ship_models (id, name, ship_manufacturer_id, ship_type_id, hull_type_id, fuel_type_id, length, beam, draught, fuel_capacity, water_capacity, no_of_engines, engine_power, engine_name, created_at, updated_at, variant) FROM stdin;
\.
COPY ship_models (id, name, ship_manufacturer_id, ship_type_id, hull_type_id, fuel_type_id, length, beam, draught, fuel_capacity, water_capacity, no_of_engines, engine_power, engine_name, created_at, updated_at, variant) FROM '$$PATH$$/2657.dat';

--
-- Name: ship_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('ship_models_id_seq', 1393, true);


--
-- Data for Name: ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ships (id, name, charter_company_id, ship_model_id, base_port_id, year_of_manufacture, no_of_engines, engine_name, engine_power, fuel_type_id, created_at, updated_at, description, length, beam, draught, fuel_capacity, water_capacity, max_no_of_people, no_of_berths, no_of_crew_cabins, no_of_heads, variant, no_of_bunk_cabins, no_of_double_cabins, no_of_skipper_cabins, hull_type_id, ship_type_id, no_of_single_cabins, no_of_triple_cabins, charter_type_id) FROM stdin;
\.
COPY ships (id, name, charter_company_id, ship_model_id, base_port_id, year_of_manufacture, no_of_engines, engine_name, engine_power, fuel_type_id, created_at, updated_at, description, length, beam, draught, fuel_capacity, water_capacity, max_no_of_people, no_of_berths, no_of_crew_cabins, no_of_heads, variant, no_of_bunk_cabins, no_of_double_cabins, no_of_skipper_cabins, hull_type_id, ship_type_id, no_of_single_cabins, no_of_triple_cabins, charter_type_id) FROM '$$PATH$$/2652.dat';

--
-- Name: ships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('ships_id_seq', 5217, true);


--
-- Data for Name: ships_transit_log_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ships_transit_log_templates (ship_id, transit_log_template_id) FROM stdin;
\.
COPY ships_transit_log_templates (ship_id, transit_log_template_id) FROM '$$PATH$$/2653.dat';

--
-- Data for Name: to_do_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY to_do_items (id, "position", text, status, created_at, updated_at, assignee_id, assignee_type, user_id, due_date) FROM stdin;
\.
COPY to_do_items (id, "position", text, status, created_at, updated_at, assignee_id, assignee_type, user_id, due_date) FROM '$$PATH$$/2659.dat';

--
-- Name: to_do_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('to_do_items_id_seq', 1, true);


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY transactions (id, transaction_status_id, check_in, check_out, base_in_id, base_out_id, charter_company_id, client_id, price, payment_type_id, agency_agreement, agent_id, creation_date, option_date, expiry_date, created_at, updated_at, notes, payment_status, reservation_date, bank_info, bank_remark) FROM stdin;
\.
COPY transactions (id, transaction_status_id, check_in, check_out, base_in_id, base_out_id, charter_company_id, client_id, price, payment_type_id, agency_agreement, agent_id, creation_date, option_date, expiry_date, created_at, updated_at, notes, payment_status, reservation_date, bank_info, bank_remark) FROM '$$PATH$$/2661.dat';

--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('transactions_id_seq', 67, true);


--
-- Data for Name: transit_log_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY transit_log_items (id, name, created_at, updated_at) FROM stdin;
\.
COPY transit_log_items (id, name, created_at, updated_at) FROM '$$PATH$$/2663.dat';

--
-- Name: transit_log_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('transit_log_items_id_seq', 13, true);


--
-- Data for Name: transit_log_items_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY transit_log_items_templates (transit_log_item_id, transit_log_template_id) FROM stdin;
\.
COPY transit_log_items_templates (transit_log_item_id, transit_log_template_id) FROM '$$PATH$$/2664.dat';

--
-- Data for Name: transit_log_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY transit_log_templates (id, name, price, created_at, updated_at, charter_company_id) FROM stdin;
\.
COPY transit_log_templates (id, name, price, created_at, updated_at, charter_company_id) FROM '$$PATH$$/2666.dat';

--
-- Name: transit_log_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('transit_log_templates_id_seq', 2, true);


--
-- Data for Name: translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY translations (id, translatable_id, translatable_type, translatable_field, locale, content, created_at, updated_at) FROM stdin;
\.
COPY translations (id, translatable_id, translatable_type, translatable_field, locale, content, created_at, updated_at) FROM '$$PATH$$/2668.dat';

--
-- Name: translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('translations_id_seq', 12, true);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at, role_id) FROM stdin;
\.
COPY users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at, role_id) FROM '$$PATH$$/2670.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_id_seq', 10, true);


--
-- Name: idx_63406_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY attachments
    ADD CONSTRAINT idx_63406_primary PRIMARY KEY (id);


--
-- Name: idx_63415_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY base_ports
    ADD CONSTRAINT idx_63415_primary PRIMARY KEY (id);


--
-- Name: idx_63427_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY base_port_managers
    ADD CONSTRAINT idx_63427_primary PRIMARY KEY (id);


--
-- Name: idx_63436_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY catalogues
    ADD CONSTRAINT idx_63436_primary PRIMARY KEY (id);


--
-- Name: idx_63445_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY charter_companies
    ADD CONSTRAINT idx_63445_primary PRIMARY KEY (id);


--
-- Name: idx_63454_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY charter_company_base_port_infos
    ADD CONSTRAINT idx_63454_primary PRIMARY KEY (id);


--
-- Name: idx_63463_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY charter_packs
    ADD CONSTRAINT idx_63463_primary PRIMARY KEY (id);


--
-- Name: idx_63475_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY deposit_items
    ADD CONSTRAINT idx_63475_primary PRIMARY KEY (id);


--
-- Name: idx_63487_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY equipment
    ADD CONSTRAINT idx_63487_primary PRIMARY KEY (id);


--
-- Name: idx_63499_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY expenses
    ADD CONSTRAINT idx_63499_primary PRIMARY KEY (id);


--
-- Name: idx_63508_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY extra_items
    ADD CONSTRAINT idx_63508_primary PRIMARY KEY (id);


--
-- Name: idx_63520_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY extra_templates
    ADD CONSTRAINT idx_63520_primary PRIMARY KEY (id);


--
-- Name: idx_63532_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY fees
    ADD CONSTRAINT idx_63532_primary PRIMARY KEY (id);


--
-- Name: idx_63538_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY images
    ADD CONSTRAINT idx_63538_primary PRIMARY KEY (id);


--
-- Name: idx_63547_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY periods
    ADD CONSTRAINT idx_63547_primary PRIMARY KEY (id);


--
-- Name: idx_63553_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY price_lists
    ADD CONSTRAINT idx_63553_primary PRIMARY KEY (id);


--
-- Name: idx_63565_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY price_per_weeks
    ADD CONSTRAINT idx_63565_primary PRIMARY KEY (id);


--
-- Name: idx_63571_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY regions
    ADD CONSTRAINT idx_63571_primary PRIMARY KEY (id);


--
-- Name: idx_63580_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY sailings
    ADD CONSTRAINT idx_63580_primary PRIMARY KEY (id);


--
-- Name: idx_63596_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY seasons
    ADD CONSTRAINT idx_63596_primary PRIMARY KEY (id);


--
-- Name: idx_63605_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY season_ships
    ADD CONSTRAINT idx_63605_primary PRIMARY KEY (id);


--
-- Name: idx_63611_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY ships
    ADD CONSTRAINT idx_63611_primary PRIMARY KEY (id);


--
-- Name: idx_63623_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY ship_manufacturers
    ADD CONSTRAINT idx_63623_primary PRIMARY KEY (id);


--
-- Name: idx_63632_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY ship_models
    ADD CONSTRAINT idx_63632_primary PRIMARY KEY (id);


--
-- Name: idx_63641_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY to_do_items
    ADD CONSTRAINT idx_63641_primary PRIMARY KEY (id);


--
-- Name: idx_63652_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY transactions
    ADD CONSTRAINT idx_63652_primary PRIMARY KEY (id);


--
-- Name: idx_63662_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY transit_log_items
    ADD CONSTRAINT idx_63662_primary PRIMARY KEY (id);


--
-- Name: idx_63674_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY transit_log_templates
    ADD CONSTRAINT idx_63674_primary PRIMARY KEY (id);


--
-- Name: idx_63683_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY translations
    ADD CONSTRAINT idx_63683_primary PRIMARY KEY (id);


--
-- Name: idx_63692_primary; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT idx_63692_primary PRIMARY KEY (id);


--
-- Name: idx_63454_index_charter_company_base_port_infos_on_base_port_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63454_index_charter_company_base_port_infos_on_base_port_id ON charter_company_base_port_infos USING btree (base_port_id);


--
-- Name: idx_63454_index_charter_company_base_port_infos_on_charter_comp; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63454_index_charter_company_base_port_infos_on_charter_comp ON charter_company_base_port_infos USING btree (charter_company_id);


--
-- Name: idx_63494_index_equipment_ships_on_equipment_id_and_ship_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63494_index_equipment_ships_on_equipment_id_and_ship_id ON equipment_ships USING btree (equipment_id, ship_id);


--
-- Name: idx_63494_index_equipment_ships_on_ship_id_and_equipment_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63494_index_equipment_ships_on_ship_id_and_equipment_id ON equipment_ships USING btree (ship_id, equipment_id);


--
-- Name: idx_63532_index_fees_on_charter_company_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63532_index_fees_on_charter_company_id ON fees USING btree (charter_company_id);


--
-- Name: idx_63538_index_images_on_item_id_and_item_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63538_index_images_on_item_id_and_item_type ON images USING btree (item_id, item_type);


--
-- Name: idx_63565_index_price_per_weeks_on_season_ship_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63565_index_price_per_weeks_on_season_ship_id ON price_per_weeks USING btree (season_ship_id);


--
-- Name: idx_63571_index_regions_on_ancestry; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63571_index_regions_on_ancestry ON regions USING btree (ancestry);


--
-- Name: idx_63585_index_sailings_transactions_on_sailing_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63585_index_sailings_transactions_on_sailing_id ON sailings_transactions USING btree (sailing_id);


--
-- Name: idx_63585_index_sailings_transactions_on_transaction_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63585_index_sailings_transactions_on_transaction_id ON sailings_transactions USING btree (transaction_id);


--
-- Name: idx_63588_unique_schema_migrations; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX idx_63588_unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: idx_63605_index_season_ships_on_season_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63605_index_season_ships_on_season_id ON season_ships USING btree (season_id);


--
-- Name: idx_63605_index_season_ships_on_ship_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63605_index_season_ships_on_ship_id ON season_ships USING btree (ship_id);


--
-- Name: idx_63611_index_ships_on_base_port_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63611_index_ships_on_base_port_id ON ships USING btree (base_port_id);


--
-- Name: idx_63611_index_ships_on_ship_model_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63611_index_ships_on_ship_model_id ON ships USING btree (ship_model_id);


--
-- Name: idx_63632_index_ship_models_on_ship_manufacturer_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63632_index_ship_models_on_ship_manufacturer_id ON ship_models USING btree (ship_manufacturer_id);


--
-- Name: idx_63652_index_transactions_on_agent_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63652_index_transactions_on_agent_id ON transactions USING btree (agent_id);


--
-- Name: idx_63652_index_transactions_on_base_in_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63652_index_transactions_on_base_in_id ON transactions USING btree (base_in_id);


--
-- Name: idx_63652_index_transactions_on_base_out_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63652_index_transactions_on_base_out_id ON transactions USING btree (base_out_id);


--
-- Name: idx_63652_index_transactions_on_charter_company_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63652_index_transactions_on_charter_company_id ON transactions USING btree (charter_company_id);


--
-- Name: idx_63652_index_transactions_on_client_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63652_index_transactions_on_client_id ON transactions USING btree (client_id);


--
-- Name: idx_63683_record_translations_index; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_63683_record_translations_index ON translations USING btree (translatable_id, translatable_type, locale);


--
-- Name: idx_63692_index_users_on_email; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX idx_63692_index_users_on_email ON users USING btree (email);


--
-- Name: idx_63692_index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX idx_63692_index_users_on_reset_password_token ON users USING btree (reset_password_token);


--
-- Name: public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

