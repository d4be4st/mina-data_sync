--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET search_path = public, pg_catalog;

--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY attachments (id, attached_to_id, attached_to_type, created_at, updated_at, file_file_name, file_content_type, file_file_size, file_updated_at, category) FROM stdin;
\.
COPY attachments (id, attached_to_id, attached_to_type, created_at, updated_at, file_file_name, file_content_type, file_file_size, file_updated_at, category) FROM '$$PATH$$/2564.dat';

--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('attachments_id_seq', 1, true);


--
-- Data for Name: base_port_managers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY base_port_managers (id, name, contact, charter_company_id, base_port_id) FROM stdin;
\.
COPY base_port_managers (id, name, contact, charter_company_id, base_port_id) FROM '$$PATH$$/2569.dat';

--
-- Name: base_port_managers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('base_port_managers_id_seq', 1, true);


--
-- Data for Name: base_ports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY base_ports (id, name, address, region_id, contact, created_at, updated_at, latitude, longitude, city, description) FROM stdin;
\.
COPY base_ports (id, name, address, region_id, contact, created_at, updated_at, latitude, longitude, city, description) FROM '$$PATH$$/2566.dat';

--
-- Data for Name: base_ports_charter_companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY base_ports_charter_companies (charter_company_id, base_port_id) FROM stdin;
\.
COPY base_ports_charter_companies (charter_company_id, base_port_id) FROM '$$PATH$$/2567.dat';

--
-- Name: base_ports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('base_ports_id_seq', 108, true);


--
-- Data for Name: catalogues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY catalogues (id, name, charter_company_id, year, active) FROM stdin;
\.
COPY catalogues (id, name, charter_company_id, year, active) FROM '$$PATH$$/2571.dat';

--
-- Name: catalogues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('catalogues_id_seq', 5, true);


--
-- Data for Name: charter_companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY charter_companies (id, code, name, fullname, city, address, phone, fax, url, email, country_code, created_at, updated_at, info, general_charter_conditions, payment_type_id, billing_method_id, account_number, transit_log_payment_id, account_for_billing, check_in_time, check_out_time, check_in_day, check_out_day, payment_instructions) FROM stdin;
\.
COPY charter_companies (id, code, name, fullname, city, address, phone, fax, url, email, country_code, created_at, updated_at, info, general_charter_conditions, payment_type_id, billing_method_id, account_number, transit_log_payment_id, account_for_billing, check_in_time, check_out_time, check_in_day, check_out_day, payment_instructions) FROM '$$PATH$$/2573.dat';

--
-- Name: charter_companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('charter_companies_id_seq', 10318, true);


--
-- Data for Name: charter_company_base_port_infos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY charter_company_base_port_infos (id, charter_company_id, base_port_id, city, address, country_code, phone, fax, info, created_at, updated_at) FROM stdin;
\.
COPY charter_company_base_port_infos (id, charter_company_id, base_port_id, city, address, country_code, phone, fax, info, created_at, updated_at) FROM '$$PATH$$/2575.dat';

--
-- Name: charter_company_base_port_infos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('charter_company_base_port_infos_id_seq', 3, true);


--
-- Data for Name: charter_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY charter_packs (id, name, description, season_id) FROM stdin;
\.
COPY charter_packs (id, name, description, season_id) FROM '$$PATH$$/2577.dat';

--
-- Name: charter_packs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('charter_packs_id_seq', 1, true);


--
-- Data for Name: charter_packs_ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY charter_packs_ships (charter_pack_id, ship_id) FROM stdin;
\.
COPY charter_packs_ships (charter_pack_id, ship_id) FROM '$$PATH$$/2578.dat';

--
-- Data for Name: deposit_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY deposit_items (id, name, price, deposit_type_id, charter_company_id) FROM stdin;
\.
COPY deposit_items (id, name, price, deposit_type_id, charter_company_id) FROM '$$PATH$$/2580.dat';

--
-- Name: deposit_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('deposit_items_id_seq', 2, true);


--
-- Data for Name: deposit_items_ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY deposit_items_ships (deposit_item_id, ship_id) FROM stdin;
\.
COPY deposit_items_ships (deposit_item_id, ship_id) FROM '$$PATH$$/2581.dat';

--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY equipment (id, name, equipment_type_id, equipment_category_id, created_at, updated_at, ship_type_id, "position") FROM stdin;
\.
COPY equipment (id, name, equipment_type_id, equipment_category_id, created_at, updated_at, ship_type_id, "position") FROM '$$PATH$$/2583.dat';

--
-- Name: equipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('equipment_id_seq', 401, true);


--
-- Data for Name: equipment_ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY equipment_ships (equipment_id, ship_id) FROM stdin;
\.
COPY equipment_ships (equipment_id, ship_id) FROM '$$PATH$$/2584.dat';

--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY expenses (id, name, description, created_at, updated_at) FROM stdin;
\.
COPY expenses (id, name, description, created_at, updated_at) FROM '$$PATH$$/2586.dat';

--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('expenses_id_seq', 1, true);


--
-- Data for Name: extra_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY extra_items (id, name, charter_company_id) FROM stdin;
\.
COPY extra_items (id, name, charter_company_id) FROM '$$PATH$$/2588.dat';

--
-- Name: extra_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('extra_items_id_seq', 2, true);


--
-- Data for Name: extra_items_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY extra_items_templates (extra_item_id, extra_template_id) FROM stdin;
\.
COPY extra_items_templates (extra_item_id, extra_template_id) FROM '$$PATH$$/2589.dat';

--
-- Data for Name: extra_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY extra_templates (id, name, charter_company_id, price) FROM stdin;
\.
COPY extra_templates (id, name, charter_company_id, price) FROM '$$PATH$$/2591.dat';

--
-- Name: extra_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('extra_templates_id_seq', 2, true);


--
-- Data for Name: extra_templates_ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY extra_templates_ships (extra_template_id, ship_id) FROM stdin;
\.
COPY extra_templates_ships (extra_template_id, ship_id) FROM '$$PATH$$/2592.dat';

--
-- Data for Name: fees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY fees (id, charter_company_id, ship_type_id, price, created_at, updated_at) FROM stdin;
\.
COPY fees (id, charter_company_id, ship_type_id, price, created_at, updated_at) FROM '$$PATH$$/2594.dat';

--
-- Name: fees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('fees_id_seq', 12, true);


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY images (id, item_id, item_type, image_type_id, image_file_name, image_content_type, image_file_size, image_updated_at, created_at, updated_at) FROM stdin;
\.
COPY images (id, item_id, item_type, image_type_id, image_file_name, image_content_type, image_file_size, image_updated_at, created_at, updated_at) FROM '$$PATH$$/2596.dat';

--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('images_id_seq', 5, true);


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY periods (id, start_date, end_date, created_at, updated_at, season_id) FROM stdin;
\.
COPY periods (id, start_date, end_date, created_at, updated_at, season_id) FROM '$$PATH$$/2598.dat';

--
-- Name: periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('periods_id_seq', 16, true);


--
-- Data for Name: price_lists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY price_lists (id, created_at, updated_at, name, season_id) FROM stdin;
\.
COPY price_lists (id, created_at, updated_at, name, season_id) FROM '$$PATH$$/2600.dat';

--
-- Name: price_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('price_lists_id_seq', 2, true);


--
-- Data for Name: price_lists_ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY price_lists_ships (price_list_id, ship_id) FROM stdin;
\.
COPY price_lists_ships (price_list_id, ship_id) FROM '$$PATH$$/2601.dat';

--
-- Data for Name: price_per_weeks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY price_per_weeks (id, season_ship_id, price, start, created_at, updated_at) FROM stdin;
\.
COPY price_per_weeks (id, season_ship_id, price, start, created_at, updated_at) FROM '$$PATH$$/2603.dat';

--
-- Name: price_per_weeks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('price_per_weeks_id_seq', 1, true);


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY regions (id, name, created_at, updated_at, parent_id, latitude, longitude, season_id, ancestry, description) FROM stdin;
\.
COPY regions (id, name, created_at, updated_at, parent_id, latitude, longitude, season_id, ancestry, description) FROM '$$PATH$$/2605.dat';

--
-- Name: regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('regions_id_seq', 50687, true);


--
-- Data for Name: sailings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY sailings (id, season_ship_id, start_date, price, price_changed) FROM stdin;
\.
COPY sailings (id, season_ship_id, start_date, price, price_changed) FROM '$$PATH$$/2607.dat';

--
-- Name: sailings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('sailings_id_seq', 203, true);


--
-- Data for Name: sailings_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY sailings_transactions (transaction_id, sailing_id) FROM stdin;
\.
COPY sailings_transactions (transaction_id, sailing_id) FROM '$$PATH$$/2608.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY schema_migrations (version) FROM stdin;
\.
COPY schema_migrations (version) FROM '$$PATH$$/2609.dat';

--
-- Data for Name: season_ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY season_ships (id, ship_id, season_id, created_at, updated_at, price) FROM stdin;
\.
COPY season_ships (id, ship_id, season_id, created_at, updated_at, price) FROM '$$PATH$$/2613.dat';

--
-- Name: season_ships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('season_ships_id_seq', 46, true);


--
-- Data for Name: seasons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY seasons (id, name, catalogue_id, price) FROM stdin;
\.
COPY seasons (id, name, catalogue_id, price) FROM '$$PATH$$/2611.dat';

--
-- Name: seasons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('seasons_id_seq', 9, true);


--
-- Data for Name: ship_manufacturers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ship_manufacturers (id, name, country_code, url, created_at, updated_at) FROM stdin;
\.
COPY ship_manufacturers (id, name, country_code, url, created_at, updated_at) FROM '$$PATH$$/2618.dat';

--
-- Name: ship_manufacturers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('ship_manufacturers_id_seq', 10321, true);


--
-- Data for Name: ship_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ship_models (id, name, ship_manufacturer_id, ship_type_id, hull_type_id, fuel_type_id, length, beam, draught, fuel_capacity, water_capacity, no_of_engines, engine_power, engine_name, created_at, updated_at, variant) FROM stdin;
\.
COPY ship_models (id, name, ship_manufacturer_id, ship_type_id, hull_type_id, fuel_type_id, length, beam, draught, fuel_capacity, water_capacity, no_of_engines, engine_power, engine_name, created_at, updated_at, variant) FROM '$$PATH$$/2620.dat';

--
-- Name: ship_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('ship_models_id_seq', 1393, true);


--
-- Data for Name: ships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ships (id, name, charter_company_id, ship_model_id, base_port_id, year_of_manufacture, no_of_engines, engine_name, engine_power, fuel_type_id, created_at, updated_at, description, length, beam, draught, fuel_capacity, water_capacity, max_no_of_people, no_of_berths, no_of_crew_cabins, no_of_heads, variant, no_of_bunk_cabins, no_of_double_cabins, no_of_skipper_cabins, hull_type_id, ship_type_id, no_of_single_cabins, no_of_triple_cabins, charter_type_id) FROM stdin;
\.
COPY ships (id, name, charter_company_id, ship_model_id, base_port_id, year_of_manufacture, no_of_engines, engine_name, engine_power, fuel_type_id, created_at, updated_at, description, length, beam, draught, fuel_capacity, water_capacity, max_no_of_people, no_of_berths, no_of_crew_cabins, no_of_heads, variant, no_of_bunk_cabins, no_of_double_cabins, no_of_skipper_cabins, hull_type_id, ship_type_id, no_of_single_cabins, no_of_triple_cabins, charter_type_id) FROM '$$PATH$$/2615.dat';

--
-- Name: ships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('ships_id_seq', 5217, true);


--
-- Data for Name: ships_transit_log_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY ships_transit_log_templates (ship_id, transit_log_template_id) FROM stdin;
\.
COPY ships_transit_log_templates (ship_id, transit_log_template_id) FROM '$$PATH$$/2616.dat';

--
-- Data for Name: to_do_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY to_do_items (id, "position", text, status, created_at, updated_at, assignee_id, assignee_type, user_id, due_date) FROM stdin;
\.
COPY to_do_items (id, "position", text, status, created_at, updated_at, assignee_id, assignee_type, user_id, due_date) FROM '$$PATH$$/2622.dat';

--
-- Name: to_do_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('to_do_items_id_seq', 1, true);


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY transactions (id, transaction_status_id, check_in, check_out, base_in_id, base_out_id, charter_company_id, client_id, price, payment_type_id, agency_agreement, agent_id, creation_date, option_date, expiry_date, created_at, updated_at, notes, payment_status, reservation_date, bank_info, bank_remark) FROM stdin;
\.
COPY transactions (id, transaction_status_id, check_in, check_out, base_in_id, base_out_id, charter_company_id, client_id, price, payment_type_id, agency_agreement, agent_id, creation_date, option_date, expiry_date, created_at, updated_at, notes, payment_status, reservation_date, bank_info, bank_remark) FROM '$$PATH$$/2624.dat';

--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('transactions_id_seq', 67, true);


--
-- Data for Name: transit_log_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY transit_log_items (id, name, created_at, updated_at) FROM stdin;
\.
COPY transit_log_items (id, name, created_at, updated_at) FROM '$$PATH$$/2626.dat';

--
-- Name: transit_log_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('transit_log_items_id_seq', 13, true);


--
-- Data for Name: transit_log_items_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY transit_log_items_templates (transit_log_item_id, transit_log_template_id) FROM stdin;
\.
COPY transit_log_items_templates (transit_log_item_id, transit_log_template_id) FROM '$$PATH$$/2627.dat';

--
-- Data for Name: transit_log_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY transit_log_templates (id, name, price, created_at, updated_at, charter_company_id) FROM stdin;
\.
COPY transit_log_templates (id, name, price, created_at, updated_at, charter_company_id) FROM '$$PATH$$/2629.dat';

--
-- Name: transit_log_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('transit_log_templates_id_seq', 2, true);


--
-- Data for Name: translations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY translations (id, translatable_id, translatable_type, translatable_field, locale, content, created_at, updated_at) FROM stdin;
\.
COPY translations (id, translatable_id, translatable_type, translatable_field, locale, content, created_at, updated_at) FROM '$$PATH$$/2631.dat';

--
-- Name: translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('translations_id_seq', 12, true);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at, role_id) FROM stdin;
\.
COPY users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at, role_id) FROM '$$PATH$$/2633.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_id_seq', 10, true);


--
-- PostgreSQL database dump complete
--

